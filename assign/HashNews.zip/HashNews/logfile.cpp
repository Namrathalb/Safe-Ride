/*======================================HEADERS=========================================*/
#include "logfile.h"
int ci=0;
/*===========================RETURNS THE CURRENT DATE & TIME=============================*/
inline QString getCurrentDateTime()  {
   QString cd = QDate::currentDate().toString("yyyy-MM-dd");
   QString ct = QTime::currentTime().toString("hh-mm-ss");
   cd.append("_");
   cd.append(ct);
   return cd;
}
/*=========================LOG FILE NAME=================================================*/
QString s = "log_" + getCurrentDateTime() + ".txt"; //Log File is created
QFile file(s);
/*=========================INTIALIZE====================================================*/
void intialise() {
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    out  << "Index" << "\t\t"
         << "TIMESTAMP" << "\t\t\t\t"
         << "Linenumber" << "\t\t"
         << "Function Name" << "\t\t\t\t\t"
         << "User value" << "\n"; ci++;
}
/*==============================OVERLOADING===============================================*/
void writelog(int y, QString x, QString h) {
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    out << ci << "\t\t" << __TIMESTAMP__ << "\t\t" << y << "\t\t\t" << x << "\t\t\t\t" << h << "\n"; ci++;
}
void writelog(int y, QString x, QString h, QString w) {
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    out << ci << "\t\t" << __TIMESTAMP__ << "\t\t" << y << "\t\t\t" << x << "\t\t\t\t" << h << w << "\n"; ci++;
}
/*==============================OVERLOADING===============================================*/
void closefile()
{
   file.close();
}
