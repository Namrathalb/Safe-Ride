#include "logfile.h"
#include <QMainWindow>
#include <stdio.h>
#include <filesystem>
#include <QFile>
#include <QDate>
#include <QTime>
#include <QTextStream>

int ci=0;

inline QString getCurrentDateTime() //RETURNS THE CURRENT DATE AND TIME TO LOG FILE NAME
{
   QString cd = QDate::currentDate().toString("yyyy-MM-dd");
   QString ct = QTime::currentTime().toString("hh-mm-ss");
   cd.append("_");
   cd.append(ct);
   return cd;
}
QString s = "log_" + getCurrentDateTime() + ".txt"; //Log File is created
QFile file(s);

void intialise()
{
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    out  << "Index" << "\t\t"
         << "TIMESTAMP" << "\t\t\t\t"
         << "Linenumber" << "\t\t"
         << "Function Name" << "\t\t\t\t\t"
         << "User value" << "\n"; ci++;
}

void writelog(int y, QString x, QString h) {
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    out << ci << "\t\t" << __TIMESTAMP__ << "\t\t" << y << "\t\t\t" << x << "\t\t\t\t" << h << "\n"; ci++;
}

void writelog(int y, QString x, QString h, QString w) {
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    out << ci << "\t\t" << __TIMESTAMP__ << "\t\t" << y << "\t\t\t" << x << "\t\t\t\t" << h << w << "\n"; ci++;
}

