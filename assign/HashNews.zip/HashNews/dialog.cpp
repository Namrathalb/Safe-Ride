#include "dialog.h"
#include "ui_dialog.h"
#include <QUrl>
#include <QWebEngineView>
Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    d(new Ui::Dialog)
{
    d->setupUi(this);
}

void Dialog::read(QString link)
{
    link.append("");
    QUrl str = QUrl(link);
    d->viewnews->load(str);
}

Dialog::~Dialog()
{
    delete d;
}
void Dialog::on_actionExit_triggered()
{
    this->close();
}

void Dialog::on_closebutton_clicked()
{
    this->close();
}
