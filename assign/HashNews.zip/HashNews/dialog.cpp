/*===========================HEADERS================================*/
#include "dialog.h"
#include "ui_dialog.h"
#include "logfile.h"
/*=========================CONSTRUCTOR===============================*/
Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    d(new Ui::Dialog)
{
    d->setupUi(this);
}
/*=========================DESTRUCTOR================================*/
Dialog::~Dialog()
{
    delete d;
}
/*=========================FUNCTION================================*/
void Dialog::read(QString link)
{
    QUrl str = QUrl(link);
    d->viewnews->load(str);
    writelog(__LINE__, "read(QString link)", "Loading: Full Article", link);
}
void Dialog::on_actionExit_triggered()
{
    this->close();
}
void Dialog::on_closebutton_clicked()
{
    this->close();
}
/*=========================FUNCTION===============================*/
