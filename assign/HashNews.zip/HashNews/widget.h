#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>


#include <QDialog>

namespace Ui {
class Widget;
}

class Widget : public QDialog
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

    void setImage(int img);
    QPixmap getPixMap(QString index);
    void viewnews(QString url);
    // Constant
    const QString iconPrint = ":/loadimg/if_print_172530.png";
    const QString iconBack = ":/loadimg/if_17_330399.png";
    const QString cacheFolder = "./cache/";
    const QString imageExtension = ".jpg";
    const QString imageError = ":/loadimg/if_ic_error_48px_351983.png";

private slots:
    void showEvent(QShowEvent *);
    void on_pushButton_back_clicked();
    void on_pushButton_print_clicked();

private:
    Ui::Widget *widget;

    // Members
    int currentNum = 0;

};

#endif // WIDGET_H
