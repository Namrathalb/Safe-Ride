#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include "dialog.h"
#include "logfile.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
	void on_pushButtonExit_clicked();
	void on_pushButtonSearch_clicked();
	void on_actionExit_triggered();
    void on_buttonexit_clicked();
    void on_buttonZoom_clicked();
    void on_buttonforward_clicked();
    void on_buttonbackward_clicked();
    void on_buttonrefresh_clicked();
    void on_buttoncancel_clicked();
    void on_actionNewWindow_triggered();
private:
    Ui::MainWindow *ui;
    Dialog *d;
    QAction* openInNewWindow;
	QString hashTag = "";
	// Constants
    const QString windowTitle = "Hash Tag News"; // Application window title
	const QString windowIcon = ":/loadimg/icon.png"; // Application icon
	const QString pushButtonSearchDefault = "Search";
};

#endif // MAINWINDOW_H
