/*===================HEADERS | CLASS DECLARATION==========================*/
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QContextMenuEvent>
#include <QWebEnginePage>
#include <QWebEngineProfile>
#include <QMessageBox>
#include <QDebug>
#include <QWebEngineView>
#include <QUrl>
#include <QObject>
#include <QClipboard>
#include "dialog.h"
#include "logfile.h"
#include "mywebenginepage.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
signals:
    void linkClicked(const QUrl &url);
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
public slots:
    void on_Exit_clicked();
    void on_Search_clicked();
	void on_actionExit_triggered();
    void on_Zoom_clicked();
    void on_Refresh_clicked();
    void on_Cancel_clicked();
    void navigate(QUrl url);
    void on_pushButton_clicked();
private:
    Ui::MainWindow *ui;
    Dialog *d;
    MyWebEnginePage *mypage;
    QAction* openInNewWindow;
	// Constants
    const QString windowTitle = "Hash Tag News"; // Application window title
	const QString windowIcon = ":/loadimg/icon.png"; // Application icon
	const QString pushButtonSearchDefault = "Search";
};

#endif // MAINWINDOW_H
/*===================HEADERS | FUNCTION DECLARATION==========================*/
