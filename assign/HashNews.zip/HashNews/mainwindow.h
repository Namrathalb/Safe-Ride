#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include "dialog.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
	void on_pushButtonExit_clicked();
	void on_pushButtonSearch_clicked();
	void on_actionExit_triggered();
    void on_buttonexit_clicked();
    void on_buttonZoom_clicked();
    void on_buttonrefresh_clicked();
    void on_buttoncancel_clicked();

private:
    Ui::MainWindow *ui;
    Dialog *d;
	QString hashTag = "";
	// Constants
    const QString windowTitle = "Hash Tag News"; // Application window title
	const QString windowIcon = ":/loadimg/icon.png"; // Application icon
	const QString pushButtonBackLoading = "Back ...... Please wait";
	const QString pushButtonBackDefault = "Back";
	const QString pushButtonSearchDefault = "Search";
    const QString urlFirstPart = "https://www.indiatoday.in/topic/";
	const QString urlNextPagePart = "&max_id=";
};

#endif // MAINWINDOW_H
