#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include <QMessageBox>
#include <QDebug>
#include <QWebEngineView>
#include <QUrl>
#include <QObject>
#include <QWebEnginePage>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	this->setWindowIcon(QIcon(windowIcon));
	this->setWindowTitle(windowTitle);
	ui->pushButtonSearch->setEnabled(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonExit_clicked()
{
    this->close();
}

void MainWindow::on_pushButtonSearch_clicked()
{
    const QString FirstPart = "https://www.indiatoday.in/topic/";
	hashTag = ui->lineEdit->text();
    QString url = FirstPart;
    url.append(hashTag);
    QUrl str = QUrl(url);
    ui->view->load(str);
    ui->tabWidget->setCurrentIndex(1);

    QAction* openInNewTab = ui->view->pageAction(QWebEnginePage::OpenLinkInNewTab);
    connect(openInNewTab, SIGNAL(triggered()), this, SLOT(on_actionNewTab_triggered()));
}


void MainWindow:: on_actionNewTab_triggered()
{
    QObject *senderObj = sender();
    QString readnews = senderObj->objectName();
    d = new Dialog ();
    d->show();
    d->read(readnews);
}
void MainWindow::on_actionExit_triggered()
{
    this->close();
}

void MainWindow::on_buttonrefresh_clicked()
{
    ui->view->reload();
}

void MainWindow::on_buttonZoom_clicked()
{
    qreal factor = ui->view->zoomFactor();
    factor += 0.1;
    if(factor > 5)
    {
        factor = 5;
    }
    ui->view->setZoomFactor(factor);
}

void MainWindow::on_buttoncancel_clicked()
{
    // Back to the first tab
  ui->tabWidget->setCurrentIndex(0);
}

void MainWindow::on_buttonexit_clicked()
{
    this->close();
}
