#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QtNetwork/QNetworkAccessManager>
#include <QDesktopServices>
#include <QUrl>
#include "widget.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
	ui->setupUi(this);

	this->setWindowIcon(QIcon(windowIcon));
	this->setWindowTitle(windowTitle);

	ui->pushButtonSearch->setEnabled(false);

	// Setup SIGNAL and SLOT
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(replyFinished(QNetworkReply*)));
    connect(m_netwManager, SIGNAL(finished(QNetworkReply*)), this, SLOT(slot_netwManagerFinished(QNetworkReply*)));
	ui->pushButtonSearch->setEnabled(true);
}

MainWindow::~MainWindow()
{
    delete ui;
	delete manager;
	delete m_netwManager;
}

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (event->type() == QEvent::MouseButtonRelease)
    {

    }

    return QMainWindow::eventFilter(watched, event);
}

void MainWindow::on_pushButtonExit_clicked()
{
    this->close();
}

void MainWindow::on_pushButtonSearch_clicked()
{
    const QString FirstPart = "https://www.indiatoday.in/topic/";
	hashTag = ui->lineEdit->text();
    QString url = FirstPart;
	url.append(hashTag);
   // QDesktopServices::openUrl(QUrl(url));
    widget = new Widget(url);
    widget->show();
}

void MainWindow::replyFinished(QNetworkReply *reply)
{

}

void MainWindow::slot_netwManagerFinished(QNetworkReply *reply)
{
    //CONNECT m_netwManager SIGNAL finished
    if (reply->error() != QNetworkReply::NoError)
    {
        qDebug() << "Error in" << reply->url() << ":" << reply->errorString();
        return;
    }
}

void MainWindow::on_actionExit_triggered()
{
    this->close();
}

void MainWindow::loadNext()
{

}


void MainWindow::on_pushButton_refresh_clicked()
{

}

void MainWindow::on_pushButton_Next_clicked()
{

}

void MainWindow::on_pushButton_Back_clicked()
{

}

void MainWindow::on_pushButton_cancel_clicked()
{
	// Back to the first tab
    ui->tabWidget->setCurrentIndex(0);
}

