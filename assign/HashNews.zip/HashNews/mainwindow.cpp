#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "logfile.h"
#include <QMessageBox>
#include <QDebug>
#include <QWebEngineView>
#include <QUrl>
#include <QObject>
#include <QWebEnginePage>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	this->setWindowIcon(QIcon(windowIcon));
	this->setWindowTitle(windowTitle);
	ui->pushButtonSearch->setEnabled(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButtonExit_clicked()
{
    this->close();
}

void MainWindow::on_pushButtonSearch_clicked()
{
    QString url;
    log(__LINE__, "constr()", "Calling: constructor()");
    hashTag = ui->lineEdit->text();
    if(ui->checkBox->isChecked())
    {
         const QString FirstPart = "https://www.indiatoday.in/topic/";
         url = FirstPart;
    }
    if(ui->checkBox_3->isChecked())
    {
        const QString FirstPart = "https://www.thehindu.com/search/?q=";
        const QString secondpart = "&order=DESC&sort=publishdate";
        hashTag.append(secondpart);
        url = FirstPart;
    }
    if(ui->checkBox_2->isChecked())
    {
        const QString FirstPart = "https://edition.cnn.com/search?size=10&q=";
        url = FirstPart;
    }
    url.append(hashTag);
    QUrl str = QUrl(url);
    ui->view->load(str);
    ui->tabWidget->setCurrentIndex(1);

    openInNewWindow = ui->view->pageAction(QWebEnginePage::OpenLinkInNewWindow);
    openInNewWindow->setObjectName("https://www.indiatoday.in/cities/delhi/story/46-year-old-businessman-killed-by-girlfriend-s-fianc-for-objecting-to-wedding-3-held-1742098-2020-11-19");
    connect(openInNewWindow, SIGNAL(triggered()), this, SLOT(on_actionNewWindow_triggered()));
}


void MainWindow:: on_actionNewWindow_triggered()
{
    QObject *senderObj = sender();
    QString readnews = senderObj->objectName();
    d = new Dialog ();
    d->show();
    d->read(readnews);
}
void MainWindow::on_actionExit_triggered()
{
    this->close();
}

void MainWindow::on_buttonbackward_clicked()
{
    ui->view->back();
}

void MainWindow::on_buttonrefresh_clicked()
{
    ui->view->reload();
}

void MainWindow::on_buttonforward_clicked()
{
    ui->view->forward();
}

void MainWindow::on_buttonZoom_clicked()
{
    qreal factor = ui->view->zoomFactor();
    factor += 0.1;
    if(factor > 5)
    {
        factor = 5;
    }
    ui->view->setZoomFactor(factor);
}

void MainWindow::on_buttoncancel_clicked()
{
    // Back to the first tab
  ui->tabWidget->setCurrentIndex(0);
}

void MainWindow::on_buttonexit_clicked()
{
    this->close();
}
