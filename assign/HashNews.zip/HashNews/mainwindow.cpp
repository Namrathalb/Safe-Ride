#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "logfile.h"
#include <QMessageBox>
#include <QDebug>
#include <QWebEngineView>
#include <QUrl>
#include <QObject>
#include <QWebEnginePage>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	this->setWindowIcon(QIcon(windowIcon));
	this->setWindowTitle(windowTitle);
    ui->Search->setEnabled(true);
    writelog(__LINE__, "MainWindow()", "Executing: Constructor()");
}

MainWindow::~MainWindow()
{
    writelog(__LINE__, "~MainWindow()", "Executing: Destructor()");
    delete ui;
}

void MainWindow::on_Search_clicked()
{
    QString url;
    hashTag = ui->lineEdit->text();
    writelog(__LINE__, "on_Search_clicked()", "Search-HashTag: #", hashTag);

    if(ui->checkBox->isChecked())
    {
         const QString FirstPart = "https://www.indiatoday.in/topic/";
         url = FirstPart;
         writelog(__LINE__, "on_Search_clicked()", "News Source: IndiaToday");

    }
    if(ui->checkBox_3->isChecked())
    {
        const QString FirstPart = "https://www.thehindu.com/search/?q=";
        const QString secondpart = "&order=DESC&sort=publishdate";
        hashTag.append(secondpart);
        url = FirstPart;
        writelog(__LINE__, "on_Search_clicked()", "News Source: The Hindu");
    }
    if(ui->checkBox_2->isChecked())
    {
        const QString FirstPart = "https://edition.cnn.com/search?size=10&q=";
        url = FirstPart;
        writelog(__LINE__, "on_Search_clicked()", "News Source: CNN");
    }
    url.append(hashTag);
    QUrl str = QUrl(url);
    ui->view->load(str);
    writelog(__LINE__, "on_Search_clicked()", "News URL: ", url);
    ui->tabWidget->setCurrentIndex(1);

    writelog(__LINE__, "on_Search_clicked()", "Calling : Mouse Right Click");
    openInNewWindow = ui->view->pageAction(QWebEnginePage::OpenLinkInNewWindow);

   // writelog(__LINE__, "on_Search_clicked()", "Selecting : OpenLinkInNewWindow");
   // connect(openInNewWindow, SIGNAL(triggered()), this, SLOT(on_actionNewWindow_triggered()));
   // writelog(__LINE__, "on_Search_clicked()", "Calling SLOT : on_actionNewWindow_triggered()");

  //  openInNewWindow = ui->view->pageAction(QWebEnginePage::OpenLinkInNewWindow);
    connect(ui->view, SIGNAL(urlChanged(QUrl)), this, SLOT(urlChangedtry(QUrl)));
  //connect(ui->view, SIGNAL(mouseDoubleClickEvent()),this, SLOT(on_actionNewWindow_triggered()));
  //  connect(openInNewWindow, SIGNAL(triggered(bool)), this, SLOT(on_actionNewWindow_triggered(bool)));

}

void MainWindow:: urlChangedtry(QUrl url)
{
     qDebug() << Q_FUNC_INFO<<"START"<<ui->view->url().toString()<<endl;
     d = new Dialog ();
     d->show();
     d->read(url.toString());
}

void MainWindow::contextMenuEvent(QContextMenuEvent *event)
{
    qDebug() << Q_FUNC_INFO<<"START"<<endl;
    clickpos = event->pos();
   // MainWindow::contextMenuEvent(event);
}

void MainWindow:: on_actionNewWindow_triggered()
{
    qDebug() << Q_FUNC_INFO<<"START"<<endl;
  //  QUrl url=ui->view->hitTestContent(clickpos).linkUrl();

    QObject *senderObj = sender();
    QString readnews = senderObj->objectName();
    writelog(__LINE__, "on_actionNewWindow_triggered()", "Capturing Article URL: ", readnews);
    d = new Dialog ();
    writelog(__LINE__, "on_actionNewWindow_triggered()", "Creating New Dialog Object");
    d->show();
    d->read(ui->view->url().toString());
    qDebug() << Q_FUNC_INFO<<"END"<<endl;
    writelog(__LINE__, "on_actionNewWindow_triggered()", "Calling: Read() to load the URL");
}

void MainWindow::on_Exit_clicked()
{
    writelog(__LINE__, "on_Exit_clicked()", "Exit: Closing UI.");
    this->close();
}

void MainWindow::on_actionExit_triggered()
{
    writelog(__LINE__, "on_actionExit_triggered()", "Exit: Performing Close Action");
    this->close();
}

void MainWindow::on_Back_clicked()
{
    writelog(__LINE__, "on_Back_clicked()", "Loading: Previous Web page / URL");
    ui->view->back();
}

void MainWindow::on_Refresh_clicked()
{
    writelog(__LINE__, "on_Refresh_clicked()", "Reloading: Current URL / Web page");
    ui->view->reload();
}

void MainWindow::on_Next_clicked()
{
    writelog(__LINE__, "on_Next_clicked()", "Loading: Forward URL / Web page");
    ui->view->forward();
}

void MainWindow::on_Zoom_clicked()
{
    qreal factor = ui->view->zoomFactor();
    writelog(__LINE__, "on_Zoom_clicked()", "Calling: Increasing WebPage Screen Larger");
    factor += 0.1;
    if(factor > 5)
    {
        factor = 5;
    }
    ui->view->setZoomFactor(factor);
}

void MainWindow::on_Cancel_clicked()
{
  writelog(__LINE__, "on_Cancel_clicked()", "Calling: Back to Main/First Tab");
  ui->tabWidget->setCurrentIndex(0);
}
