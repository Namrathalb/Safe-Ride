/*=======================================HEADERS=========================================*/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "logfile.h"
#include "mywebenginepage.h"
/*======================================CONSTRUCTOR======================================*/
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
	this->setWindowIcon(QIcon(windowIcon));
	this->setWindowTitle(windowTitle);
    ui->Search->setEnabled(true);
    mypage = new MyWebEnginePage;
    ui->view->setPage(mypage);
    Progressbar = new QProgressBar;
    Progressbar->setGeometry(270, 423, 300, 50);
    Progressbar->setWindowModality(Qt::ApplicationModal);
    connect(mypage, SIGNAL(loadProgress(int)), Progressbar, SLOT(setValue(int)));
    connect(mypage, SIGNAL(loadFinished(bool)), Progressbar, SLOT(close()));
    connect(mypage, SIGNAL(linkClicked(QUrl)), this, SLOT(navigate(QUrl)));
    writelog(__LINE__, "MainWindow()", "\tStarting... Constructor()");
}
/*======================================DESTRUCTOR=======================================*/
MainWindow::~MainWindow()
{
    writelog(__LINE__, "~MainWindow()", "\tStarting... Destructor()");
    delete ui;
}
/*====================================SEARCH BUTTON======================================*/
void MainWindow::on_Search_clicked()
{
    QString url;
    writelog(__LINE__, "Search_clicked()", "Search-HashTag: #", ui->lineEdit->text());
        if(ui->radioButton->isChecked())
        {
             url = "https://indianexpress.com/?s="+ui->lineEdit->text();
             writelog(__LINE__, "Search_clicked()", "News Source: indianexpress");
        }
        if(ui->radioButton_2->isChecked())
        {
            url = "https://www.thehindu.com/search/?q="+ui->lineEdit->text()+"&order=DESC&sort=publishdate";
            writelog(__LINE__, "Search_clicked()", "News Source: The Hindu");
        }
        if(ui->radioButton_3->isChecked())
        {
            url = "https://edition.cnn.com/search?size=10&q="+ui->lineEdit->text();
            writelog(__LINE__, "Search_clicked()", "News Source: CNN");
        }
    QUrl str = QUrl(url);
    ui->view->load(str);
    writelog(__LINE__, "Search_clicked()", "News URL: ", url);
    ui->tabWidget->setCurrentIndex(1);
    Progressbar->show();
    writelog(__LINE__, "Search_clicked()", "WebResults : News articles List");
}
/*====================================SIGNAL NAVIGATE=======================================*/
void MainWindow::navigate(QUrl url)
{
    qDebug() << Q_FUNC_INFO << "START" << url;
    writelog(__LINE__, "navigate(QUrl url)", "Capturing Article URL: ", url.toString());
    d = new Dialog();
    d->read(url.toString());
    d->show();
    writelog(__LINE__, "navigate(QUrl url)", "Creating New Dialog Object");
}
/*======================================EXIT BUTTON=========================================*/
void MainWindow::on_Exit_clicked()
{
    writelog(__LINE__, "Exit_clicked()", "\tExit: Closing UI.");
    this->close();
}
void MainWindow::on_actionExit_triggered()
{
    writelog(__LINE__, "Exit_triggered()", "Exit: Performing Close Action");
    this->close();
}
/*====================================REFRESH BUTTON=======================================*/
void MainWindow::on_Refresh_clicked()
{
    writelog(__LINE__, "Refresh_clicked()", "Reloading: Current URL / Web page");
    ui->view->reload();
}
/*======================================SCROLL BUTTON=========================================*/
void MainWindow::on_pushButton_clicked()
{
    ui->view->page()->triggerAction(QWebEnginePage::Stop);
    QString code = "$('html, body').animate({scrollTop: 1100}, 800);";
    mypage->runJavaScript(code);
}
/*======================================ZOOM BUTTON========================================*/
void MainWindow::on_Zoom_clicked()
{
    qreal factor = ui->view->zoomFactor();
    writelog(__LINE__, "Zoom_clicked()", "Staring Zoom..");
    factor += 0.1;
    if(factor > 5)
    {
        factor = 5;
    }
    ui->view->setZoomFactor(factor);
}
/*======================================CANCEL BUTTON=========================================*/
void MainWindow::on_Cancel_clicked()
{
  writelog(__LINE__, "Cancel_clicked()", "Calling: Back to Main/First Tab");
  ui->tabWidget->setCurrentIndex(0);
}
