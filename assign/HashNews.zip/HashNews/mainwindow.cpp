/*=======================================HEADERS=========================================*/
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "logfile.h"
#include "mywebenginepage.h"
/*======================================CONSTRUCTOR======================================*/
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
	this->setWindowIcon(QIcon(windowIcon));
	this->setWindowTitle(windowTitle);
    ui->Search->setEnabled(true);
    mypage = new MyWebEnginePage;
    ui->view->setPage(mypage);
    mypage->profile()->setHttpUserAgent("Mozilla/5.0 (Linux; <Android Version>; <Build Tag etc.>) AppleWebKit/<WebKit Rev> (KHTML, like Gecko) Chrome/<Chrome Rev> Mobile Safari/<WebKit Rev>");

    progressbar = new QProgressBar;
    progressbar->setGeometry(270, 423, 300, 50);
    progressbar->setWindowModality(Qt::ApplicationModal);
    connect(mypage, SIGNAL(loadProgress(int)), progressbar, SLOT(setValue(int)));
    connect(mypage, SIGNAL(loadFinished(bool)), progressbar, SLOT(close()));
    connect(mypage, SIGNAL(linkClicked(QUrl)), this, SLOT(navigate(QUrl)));


    writelog(__LINE__, "MainWindow()", "\tStarting... Constructor()");
}
/*======================================DESTRUCTOR=======================================*/
MainWindow::~MainWindow()
{
    writelog(__LINE__, "~MainWindow()", "\tStarting... Destructor()");
    closefile();
    delete ui;
}
/*====================================SEARCH BUTTON======================================*/
void MainWindow::on_Search_clicked()
{
    QUrl url;
    writelog(__LINE__, "Search_clicked()", "Search-HashTag: #", ui->lineEdit->text());
        if(ui->radioButton->isChecked())
        {
             url =  QUrl("https://www.newindianexpress.com/topic?term="+ui->lineEdit->text()+"&request=ALL");
             writelog(__LINE__, "Search_clicked()", "News Source: indianexpress");
        }
        if(ui->radioButton_2->isChecked())
        {
            url =  QUrl("https://www.thehindu.com/search/?q="+ui->lineEdit->text()+"&order=DESC&sort=publishdate");
            writelog(__LINE__, "Search_clicked()", "News Source: The Hindu");
        }
        if(ui->radioButton_3->isChecked())
        {
            url = QUrl("https://edition.cnn.com/search?q="+ui->lineEdit->text());
            writelog(__LINE__, "Search_clicked()", "News Source: CNN");
        }
    ui->view->load(url);
    connect(ui->view->page(), &QWebEnginePage::loadFinished, this, &MainWindow::on_PageLoadFinished);
    writelog(__LINE__, "Search_clicked()", "News URL: ", url.toString());
    ui->tabWidget->setCurrentIndex(1);
    progressbar->show();
    writelog(__LINE__, "Search_clicked()", "WebResults : News articles List");
}
/*====================================SIGNAL NAVIGATE=======================================*/
void MainWindow::navigate(QUrl url)
{
    qDebug() << Q_FUNC_INFO << "START" << url;
    writelog(__LINE__, "navigate(QUrl url)", "Capturing Article URL: ", url.toString());
    d = new Dialog();
    d->read(url.toString());
    d->show();
    writelog(__LINE__, "navigate(QUrl url)", "Creating New Dialog Object");
}
/*======================================EXIT BUTTON=========================================*/
void MainWindow::on_Exit_clicked()
{
    writelog(__LINE__, "Exit_clicked()", "\tExit: Closing UI.");
    this->close();
}
void MainWindow::on_actionExit_triggered()
{
    writelog(__LINE__, "Exit_triggered()", "Exit: Performing Close Action");
    this->close();
}
/*====================================REFRESH BUTTON=======================================*/
void MainWindow::on_Refresh_clicked()
{
    writelog(__LINE__, "Refresh_clicked()", "Reloading: Current URL / Web page");
    ui->view->reload();
}
/*======================================SCROLL BUTTON=========================================*/
/*void MainWindow::on_pushButton_clicked()
{
    ui->view->page()->triggerAction(QWebEnginePage::Stop);
    writelog(__LINE__, "on_scroll_clicked", "Removing ads/overlapping content from webpage");
    if(ui->radioButton->isChecked())
    {
         QString code = "$('html, body').animate({scrollTop: 1500}, 8000);";
         QString code2 = "$('div#PE-chicklet.chicklet-right-center').remove();";
         QString code3 = "$('div.well.advance_search').remove();";
         mypage->runJavaScript(code2);
         mypage->runJavaScript(code3);
         mypage->runJavaScript(code);
    }
    if(ui->radioButton_2->isChecked())
    {
        QString showonly = "$('div.main.searchpagenew').show();";
        QString code1 = "$('div.mobileadsubentry.hidden-sm.hidden-md.hidden-lg').remove();";
        QString code2 = "$('div.co-bannerparent').remove();";
        QString code = "$('html, body').animate({scrollTop: 1175}, 8000);";
        mypage->runJavaScript(showonly);
        mypage->runJavaScript(code1);
        mypage->runJavaScript(code2);
        mypage->runJavaScript(code);
    }
    if(ui->radioButton_3->isChecked())
    {
        QString code = "$('html, body').animate({scrollTop: 1200}, 8000);";
        mypage->runJavaScript(code);
    }
    writelog(__LINE__, "on_scroll_clicked", "Scrolling articles slowly");
}*/

void MainWindow::on_pushButton_clicked()
{
    ScrollPage();
}

void MainWindow::on_PageLoadFinished()
{
       disconnect(mypage, &QWebEnginePage::loadFinished, this, &MainWindow::on_PageLoadFinished);

      ui->view->page()->triggerAction(QWebEnginePage::Stop);
      ui->view->page()->runJavaScript("document.body.scrollHeight",[&](const QVariant &result) {set_PageHeight();});
}
void MainWindow::set_PageHeight()
{
      if(ui->radioButton->isChecked())
          ThePageHeight = 1111;
      if(ui->radioButton_2->isChecked())
          ThePageHeight = 2120;
      if(ui->radioButton_3->isChecked())
          ThePageHeight = 744;
}

void MainWindow::ScrollPage()
{
       TheCurrentVerticalScroll = 0;
       while (TheCurrentVerticalScroll <= ThePageHeight)
       {
           ui->view->page()->runJavaScript(QString("window.scrollTo(0, %1);").arg(TheCurrentVerticalScroll));
           TheCurrentVerticalScroll += 3;
           QEventLoop loop;
           QTimer t;
           t.connect(&t, &QTimer::timeout, &loop, &QEventLoop::quit);
           t.start(30);
           loop.exec();
           qApp->processEvents();
       }
}
/*======================================ZOOM BUTTON========================================*/
void MainWindow::on_Zoom_clicked()
{
    qreal factor = ui->view->zoomFactor();
    writelog(__LINE__, "Zoom_clicked()", "Staring Zoom..");
    factor += 0.1;
    if(factor > 5)
    {
        factor = 5;
    }
    ui->view->setZoomFactor(factor);
}
/*======================================CANCEL BUTTON=========================================*/
void MainWindow::on_Cancel_clicked()
{
  writelog(__LINE__, "Cancel_clicked()", "Calling: Back to Main/First Tab");
  ui->tabWidget->setCurrentIndex(0);
}
