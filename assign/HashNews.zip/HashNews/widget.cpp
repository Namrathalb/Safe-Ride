/*#include "widget.h"
#include "ui_widget.h"
#include <QUrl>
#include <QWebEngineHistory>
#include <QWebEnginePage>

Widget::Widget(QString url)
{
 // ui->setupUi(this);
  QUrl str = QUrl(url);
  wid->view->load(str);
}


Widget::~Widget()
{
    delete wid;
}

void Widget::on_buttonBrowse_clicked()
{

}
void Widget::on_buttonPre_clicked()
{
    QWebEngineHistory* history = wid->view->history();
    history->back();
}

void Widget::on_buttonNext_clicked()
{
    QWebEngineHistory* history = wid->view->history();
    history->forward();
}

void Widget::on_buttonInspect_clicked()
{


}

void Widget::on_buttoncancel_clicked()
{

}


void Widget::on_buttonZoom_clicked()
{
    qreal factor = wid->view->zoomFactor();
    factor += 0.1;
    if(factor > 5)
    {
        factor = 5;
    }
    wid->view->setZoomFactor(factor);
}

void Widget::on_buttonDefault_clicked()
{
    wid->view->setZoomFactor(1.0);
}
*/
