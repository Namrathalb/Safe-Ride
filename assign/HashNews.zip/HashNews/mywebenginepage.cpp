/*======================================HEADERS=========================================*/
#include "mywebenginepage.h"
/*======================================acceptNavigationRequest Overiding=========================================*/
bool MyWebEnginePage::acceptNavigationRequest(const QUrl &url, QWebEnginePage::NavigationType type, bool isMainFrame)
{
    if (type == QWebEnginePage::NavigationTypeLinkClicked)
    {
        qDebug() << Q_FUNC_INFO <<"Start "<<type<< "url" <<url.toString(); // retrieve the url here
        emit linkClicked(url);
        return false;
    }
    return true;
}
/*======================================OVERRIDING=========================================*/
