#ifndef LOGFILE_H
#define LOGFILE_H

#define _CRT_SECURE_NO_WARNINGS
#include <QMainWindow>
#include <iostream>
#include <QString>
#include <stdio.h>
using namespace std;

void intialise();
template <typename T>
void log(int y, QString x, T const& h);
template <typename T>
void log(int y, QString x, T const& h, int w);
template <typename T>
void log(int y, QString x, T const& h, QString q);

#endif // LOGFILE_H
