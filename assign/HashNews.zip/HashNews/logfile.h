#ifndef LOGFILE_H
#define LOGFILE_H

#define _CRT_SECURE_NO_WARNINGS
#include <QMainWindow>
#include <iostream>
#include <QString>
#include <stdio.h>
using namespace std;

void intialise();
void writelog(int y, QString x, QString h);
void writelog(int y, QString x, QString h, QString w);

#endif // LOGFILE_H
