#include "News.h"
#include <QFile>
#include <QDesktopServices>
#include <QFont>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QJsonObject>
#include <QDebug>


