#include "performancecounter.h"
#include <QTimer>
#include <QDebug>

//CONST PWSTR COUNTER_PATH = L"\\Process(newsApp_gui)\\% Processor Time";
//CONST ULONG SAMPLE_INTERVAL_MS = 1000;

performanceCounter::performanceCounter()
{

}

#pragma comment(lib, "pdh.lib")



void performanceCounter::DisplayCommandLineHelp(void)
{
    wprintf(L"The command line must include a valid log file name.\n");
}

void performanceCounter::initialize()
{
    // Open a query object.
    pdhStatus = PdhOpenQuery(NULL, 0, &hQuery);
    if (pdhStatus != ERROR_SUCCESS)
    {
        wprintf(L"PdhOpenQuery failed with 0x%x\n", pdhStatus);
        cleanup();
    }

    // Add one counter that will provide the data.
    pdhStatus = PdhAddCounter(hQuery,
        L"\\Process(newsApp_gui)\\% Processor Time",
        0,
        &hCounter);
    pdhStatus = PdhAddCounter(hQuery,
        L"\\Process(newsApp_gui)\\Working Set - Private",
        0,
        &hCounter);
    pdhStatus = PdhAddCounter(hQuery,
        L"\\Process(_TOTAL)\\% Processor Time",
        0,
        &hCounter);
    pdhStatus = PdhAddCounter(hQuery,
        L"\\Process(_TOTAL)\\Working Set - Private",
        0,
        &hCounter);

    if (pdhStatus != ERROR_SUCCESS)
    {
        wprintf(L"PdhAddCounter failed with 0x%x\n", pdhStatus);
        cleanup();
    }

    // Open the log file for write access.
    pdhStatus = PdhOpenLog(L"test.log",
        PDH_LOG_WRITE_ACCESS | PDH_LOG_CREATE_ALWAYS,
        &dwLogType,
        hQuery,
        0,
        NULL,
        &hLog);

    if (pdhStatus != ERROR_SUCCESS)
    {
        wprintf(L"PdhOpenLog failed with 0x%x\n", pdhStatus);
        cleanup();
    }
}

void performanceCounter::cleanup()
{
    // Close the log file.
    if (hLog)
        PdhCloseLog(hLog, 0);

    // Close the query object.
    if (hQuery)
        PdhCloseQuery(hQuery);
}

void performanceCounter::write2file()
{
    wprintf(L"Writing record\n");
    pdhStatus = PdhUpdateLog(hLog, NULL);

    if (ERROR_SUCCESS != pdhStatus)
    {
        wprintf(L"PdhUpdateLog failed with 0x%x\n", pdhStatus);
        cleanup();
    }
}
