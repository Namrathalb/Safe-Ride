/*===================HEADERS | CLASS DECLARATION==========================*/
#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QWebEnginePage>
#include <QUrl>
#include <QWebEngineView>
#include <QWebEngineProfile>
#include <QTimer>
namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT
public:
    explicit Dialog(QWidget *parent = nullptr);
    void read(QString link);
    void set_PageHeight();
    void ScrollPage();
    ~Dialog();
private slots:
    void on_actionExit_triggered();
    void on_Scroll_clicked();
    void on_PageLoadFinished();
private:
    Ui::Dialog *d;
    QWebEnginePage *page;
    int TheCurrentVerticalScroll;
    int ThePageHeight;
};

#endif // DIALOG_H
/*===================HEADERS | CLASS DECLARATION==========================*/
