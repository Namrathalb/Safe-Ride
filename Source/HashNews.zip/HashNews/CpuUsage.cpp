#include "CpuUsage.h"
const char* argv[] = {"HashNews.exe", "test.csv", "60"};

CpuUsage::CpuUsage() {

}

CpuUsage::~CpuUsage()
{
    PdhRemoveCounter(m_cpuTotal);
    PdhRemoveCounter(m_cpuTotal);
    PdhCloseQuery(m_processQuery);
    PdhCloseQuery(m_processCpu);
}

double CpuUsage::getTotalUsage() {
    PdhCollectQueryData(m_query);
    PdhGetFormattedCounterValue(m_cpuTotal, PDH_FMT_DOUBLE, NULL, &m_counterVal);
    return m_counterVal.doubleValue;
}

double CpuUsage::getProcessUsage() {
    PdhCollectQueryData(m_processQuery);
    PdhGetFormattedCounterValue(m_processCpu, PDH_FMT_LONG | PDH_FMT_NOCAP100, 0, &m_processCounterVal);
    return m_processCounterVal.longValue;
}
void CpuUsage::intialize()
{
    // set Total Cpu query
    PdhOpenQuery(NULL, NULL, &m_query);
    PdhAddCounter(m_query, L"\\Processor(_Total)\\% Processor Time", NULL, &m_cpuTotal);
    PdhCollectQueryData(m_query);

   // set Process Cpu query
    PdhOpenQuery(NULL, 0, &m_processQuery);
    PdhAddCounter(m_processQuery,  L"\\Process(HashNews)\\% Processor Time", 0, &m_processCpu);
    PdhCollectQueryData(m_processQuery);

    ofstream outputFile(argv[1], ios::app);
    cout << "Write CPU Usage to " << argv[1] << '\n';
    totalUsage = getTotalUsage();
    int i=0;
    cout << std::internal << std::setw(3) << i << ". Cpu Usage: " << fixed << setprecision(4) << totalUsage << "%" << '\n';
    outputFile << i << "," << totalUsage << "\n";
    i++;
}

void CpuUsage::avg()
{
    ofstream outputFile(argv[1], ios::app);
    average = (average / (atoi(argv[2]) - 1));
    cout << "Average: " << average << "%" << '\n';
    outputFile << "Average" << "," << average << "\n";
    for (int i = 0; i < atoi(argv[2]); i++) {
        if (i != 0) // drop the first data
            average += totalUsage;
    }
    outputFile.close();
}

void CpuUsage::updatelog()
{
    ofstream outputFile(argv[1], ios::app);
    cout << "Write CPU Usage to " << argv[1] << '\n';
    outputFile << "Time,Total Cpu\n";
    intialize();
}
