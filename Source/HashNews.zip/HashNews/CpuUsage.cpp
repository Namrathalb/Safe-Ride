#include "CpuUsage.h"

CpuUsage::CpuUsage() {

}

void CpuUsage::cleanup()
{
   // Close the log file.
       if (log)
           PdhCloseLog(log, 0);

       // Close the query object.
       if (m_query)
           PdhCloseQuery(m_query);
}

double CpuUsage::getTotalUsage() {
    PdhCollectQueryData(m_query);
    PdhGetFormattedCounterValue(m_cpu, PDH_FMT_DOUBLE, NULL, &m_counterVal);
    return m_counterVal.doubleValue;
}

/*double CpuUsage::getProcessUsage() {
    PdhCollectQueryData(m_processQuery);
    PdhGetFormattedCounterValue(m_processCpu, PDH_FMT_LONG | PDH_FMT_NOCAP100, 0, &m_processCounterVal);
    return m_processCounterVal.longValue;
}*/
void CpuUsage::intialize()
{
    // Open a query object.
       pdhStatus = PdhOpenQuery(NULL, 0, &m_query);
       if (pdhStatus != ERROR_SUCCESS)
       {
           wprintf(L"PdhOpenQuery failed with 0x%x\n", pdhStatus);
           cleanup();
       }

       // Add one counter that will provide the data.
       pdhStatus = PdhAddCounter(m_query, L"\\Process(HashNews)\\% Processor Time", 0, &m_cpu);
       pdhStatus = PdhAddCounter(m_query, L"\\Process(HashNews)\\Working Set - Private", 0, &m_cpu);
       pdhStatus = PdhAddCounter(m_query, L"\\Process(_TOTAL)\\% Processor Time", 0, &m_cpu);
       pdhStatus = PdhAddCounter(m_query, L"\\Process(_TOTAL)\\Working Set - Private", 0, &m_cpu);

       if (pdhStatus != ERROR_SUCCESS)
       {
           std::cout<< "PdhAddCounter failed with 0x%x\n" << pdhStatus ;
           cleanup();
       }

       // Open the log file for write access.
       pdhStatus = PdhOpenLog(L"test.log", PDH_LOG_WRITE_ACCESS | PDH_LOG_CREATE_ALWAYS, &dwLogType, m_query, 0, NULL, &log);

       if (pdhStatus != ERROR_SUCCESS)
       {
           wprintf(L"PdhOpenLog failed with 0x%x\n", pdhStatus);
           cleanup();
       }
}

void CpuUsage::avg()
{

}

void CpuUsage::updatelog()
{
    std::cout<<"Writing record\n";
        pdhStatus = PdhUpdateLog(log, NULL);

        if (ERROR_SUCCESS != pdhStatus)
        {
            wprintf(L"PdhUpdateLog failed with 0x%x\n", pdhStatus);
            cleanup();
        }
}
