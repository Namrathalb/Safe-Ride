/*======================================HEADERS=========================================*/
#include "mainwindow.h"
#include "logfile.h"
#include <QApplication>
#include <QFile>
/*======================================MAIN=========================================*/
int main(int argc, char *argv[])
{
    intialise();
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
/*======================================MAIN=========================================*/
