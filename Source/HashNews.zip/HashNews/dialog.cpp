/*===========================HEADERS================================*/
#include "dialog.h"
#include "ui_dialog.h"
#include "logfile.h"
/*=========================CONSTRUCTOR===============================*/
Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    d(new Ui::Dialog)
{
    d->setupUi(this);
    page = new QWebEnginePage;
    d->viewnews->setPage(page);
    TheCurrentVerticalScroll = 0;
    writelog(__LINE__, "MainWindow()", "\tOpening New Dialog");
}
/*=========================DESTRUCTOR================================*/
Dialog::~Dialog()
{
    ThePageHeight = -1;
    TheCurrentVerticalScroll = 0;
    delete d;
}
/*=========================FUNCTION================================*/
void Dialog::read(QString link)
{
    ThePageHeight = 2000;
    QUrl str = QUrl(link);
    d->viewnews->load(str);
    writelog(__LINE__, "read(QString link)", "Loading: Full Article", link);
}
void Dialog::on_actionExit_triggered()
{
    this->close();
}
void Dialog::on_Scroll_clicked()
{
     writelog(__LINE__, "on_scroll_clicked()", "Scroll: User Reading Article");
     ScrollPage();
}
void Dialog::ScrollPage()
{
       writelog(__LINE__, "ScrollPage()", "\tScroll: Article Begin");
       while (TheCurrentVerticalScroll <= ThePageHeight)
       {
           QEventLoop loop;
           d->viewnews->page()->runJavaScript(QString("window.scrollTo(0, %1);").arg(TheCurrentVerticalScroll));
           TheCurrentVerticalScroll += 1.5;
           QTimer t;
           t.connect(&t, &QTimer::timeout, &loop, &QEventLoop::quit);
           t.start(30);
           loop.exec();
           qApp->processEvents();
       }
        writelog(__LINE__, "ScrollPage()", "\tScroll: Article End");
}
/*=========================FUNCTION===============================*/
