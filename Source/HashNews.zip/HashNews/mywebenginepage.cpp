/*======================================HEADERS=========================================*/
#include "mywebenginepage.h"
/*======================================acceptNavigationRequest Overiding=========================================*/
bool MyWebEnginePage::acceptNavigationRequest(const QUrl &url, QWebEnginePage::NavigationType type, bool isMainFrame)
{
    if (type == QWebEnginePage::NavigationTypeLinkClicked && isMainFrame == true)
    {
        qDebug() << Q_FUNC_INFO <<"Start "<<type<< "url" <<url.toString(); // retrieve the url here
        emit linkClicked(url);
        return false;
    }
    return true;
}
/*======================================CreateWindow Overiding=========================================*/
QWebEnginePage *MyWebEnginePage::createWindow(QWebEnginePage::WebWindowType type)
{
     qDebug() << Q_FUNC_INFO <<"Start "<<type<< "url clicked by user" ;
     QWebEnginePage *page = new QWebEnginePage();
     connect(page, &QWebEnginePage::urlChanged, this, [this] (const QUrl &url) { emit newPageUrlChanged(url);});
     return page;
}
/*======================================OVERRIDING=========================================*/
