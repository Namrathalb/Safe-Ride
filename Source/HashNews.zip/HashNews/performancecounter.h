#ifndef PERFORMANCECOUNTER_H
#define PERFORMANCECOUNTER_H
#include <windows.h>
#include <stdio.h>
#include <pdh.h>
#include <pdhmsg.h>
#include <fstream>
class performanceCounter
{
private:
    HQUERY hQuery = NULL;
    HLOG hLog = NULL;
    PDH_STATUS pdhStatus,pdhStatus1;
    DWORD dwLogType = PDH_LOG_TYPE_CSV;
    HCOUNTER hCounter;

public:
    performanceCounter();
    void DisplayCommandLineHelp(void);
    void initialize();
    void cleanup();
    void write2file();
};

#endif // PERFORMANCECOUNTER_H
