#ifndef PERFMON_H
#define PERFMON_H
#include <Pdh.h>
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <QString>
#include "psapi.h"

using namespace std;
#pragma comment(lib,"Pdh.lib")

class CpuUsage {
public:
    explicit CpuUsage();
    ~CpuUsage();
    double getTotalUsage();
    double getProcessUsage();
    void intialize();
    void avg();
    void updatelog();
private:
    double totalUsage = 0;
    double echoLoaderUsage = 0;
    double average;
    PDH_HQUERY m_query, m_processQuery;
    PDH_HCOUNTER m_cpuTotal,  m_processCpu;
    PDH_FMT_COUNTERVALUE m_counterVal, m_processCounterVal;
};
#endif // PERFMON_H
